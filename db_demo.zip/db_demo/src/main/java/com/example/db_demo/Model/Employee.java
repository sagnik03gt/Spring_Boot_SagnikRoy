package com.example.db_demo.Model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "User_name",unique = true)
    private String username;

    @Column(nullable = false)
    private String password;
}
